<h2>Dashboard</h2>

<div class="info"><b>Selamat datang di website PLN KITA</b></div>

<header>
    <img src="img/logopln.png" class="home" style="width: 350px; height: 350px;">
    <div class="user">MENERANGI KITA BERSAMA, HEHE</div>
</header>
